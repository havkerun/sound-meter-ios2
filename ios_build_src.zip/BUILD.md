# 打包指南：安卓 APK 与苹果 IPA

> 前提：已经按 `README.md` 跑通了 `flutter run`（能在手机上看到界面并开始测量）。打包只是把"能跑"变成"能装到别人手机上"。

---

## 零、本工程已内置的配置（不用重做）

| 事项 | 状态 |
|---|---|
| 麦克风权限 `RECORD_AUDIO` + 屏幕常亮 `WAKE_LOCK` | ✅ 已写入 `android/app/src/main/AndroidManifest.xml` |
| 应用名 | ✅ 已设为「曾哥声压测量」 |
| 启动图标（仪表盘造型，全 dpi） | ✅ `mipmap-*/ic_launcher.png` 已生成，源图为 `assets/app_icon.png` |
| 发布签名 | ✅ `android/app/key.jks` + `android/key.properties` 已配好，`build.gradle.kts` 已引用 |
| minSdk | 跟随 Flutter 默认值（Android 7.0+），满足 record 插件要求 |
| iOS 工程 `ios/` | ✅ 已生成并配好：显示名、麦克风说明、竖屏、15 个尺寸图标、Podfile、CI 工作流 |

> 两端显示名均为「曾哥声压测量」。Android 包已在本机构建完成（见 `dist/`）；iOS 依赖 macOS 工具链，需按第二节操作。

**签名密钥说明（重要）**：
- 密钥文件：`android/app/key.jks`，别名 `soundmeter`，密码均为 `sm2026pass`（记录在 `android/key.properties`）；
- `.gitignore` 已排除 `*.jks` 与 `key.properties`，**请自行备份这两样**——丢了就无法给同一个 App 发更新，只能换包名重发；
- 若要换成你自己的密钥，按下面「三、出正式 Release 包」的步骤重新生成并覆盖这两个文件即可。

---

## 一、安卓 APK

### 1. 环境准备

| 需要的 | 说明 |
|---|---|
| Flutter SDK | **3.44+**（record 7.x 的最低要求） |
| JDK | **17**（Android Gradle Plugin 9.x 要求，Java 21 部分老 AGP 会报错） |
| Android SDK | 通过 Android Studio 的 SDK Manager 装，**必须勾选 Android SDK Command-line Tools** |
| 一台开了「开发者选项 → USB 调试」的手机 | 也可用模拟器，但模拟器没有真实麦克风，测出来的没意义 |

自检：

```bash
flutter doctor -v
```

`Android toolchain` 那一项必须是 `[✓]`。

### 2. 先出个能装的 Debug 包（30 秒）

```bash
flutter build apk --debug
```

产物：`build/app/outputs/flutter-apk/app-debug.apk`

装到手机：

```bash
adb install -r build/app/outputs/flutter-apk/app-debug.apk
```

也可以把这个 apk 直接发微信/邮件给对方，手机上点开允许"未知来源安装"即可（debug 包能装，只是体积大、性能略差）。

### 3. 出正式 Release 包（需要签名）

**第一步：生成签名密钥**（只需做一次，务必备份 .jks 文件，丢了就没法给同一个应用发更新）

```bash
keytool -genkey -v -keystore sound-meter.jks -keyalg RSA -keysize 2048 -validity 10000 -alias soundmeter
```

会依次问你密码、姓名、组织等，随便填，记住密码。把 `sound-meter.jks` 放到 `android/app/` 目录下。

**第二步：新建 `android/key.properties`**

```properties
storePassword=你刚才设的密码
keyPassword=你刚才设的密码
keyAlias=soundmeter
storeFile=sound-meter.jks
```

（`storeFile` 相对 `android/app/` 目录）

**第三步：在 `android/app/build.gradle` 里引用**

Groovy 写法（老工程）：

```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    ...
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile file(keystoreProperties['storeFile'])
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled false
        }
    }
}
```

Kotlin DSL 写法（`build.gradle.kts`，新版默认）：

```kotlin
import java.util.Properties
import java.io.FileInputStream

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        create("release") {
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
        }
    }
}
```

**第四步：打包**

```bash
flutter build apk --release
```

产物：`build/app/outputs/flutter-apk/app-release.apk`

按 CPU 架构拆分（体积小很多，推荐给朋友单独发）：

```bash
flutter build apk --release --split-per-abi
```

会得到三个包，现在手机基本都是 `app-arm64-v8a-release.apk`。

### 4. 安装与验证

```bash
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

打开后先给麦克风权限 → 首页点「开始测量」→ 对着安静房间应该读到 30–45 dB 左右，正常说话时跳到 55–70 dB。如果一直是 0 或 120，回看 `mic_source.dart` 里的注释排查。

---

## 二、苹果 IPA

### ⚠️ 先明确一件事

**IPA 只能在 macOS + Xcode 上编译**。这是苹果工具链的限制，Windows / Linux 上无论装什么软件都出不了 IPA，跟本项目代码无关。

本工程已经把 iOS 端需要手工配的东西全部配好了（见下），你在 Mac 上只需要执行命令，不用打开 Xcode 逐个点。

### 本工程 iOS 端已配好的内容

| 事项 | 状态 |
|---|---|
| `ios/` 完整工程（Flutter 3.47 模板，含 SceneDelegate） | ✅ 已生成 |
| 应用显示名 | ✅ `CFBundleDisplayName = 曾哥声压测量` |
| 麦克风权限说明 `NSMicrophoneUsageDescription` | ✅ 已写入（缺这条会一点开始就闪退） |
| 屏幕方向 | ✅ 已锁竖屏（声级计界面按竖屏设计） |
| App 图标全套 15 个尺寸 | ✅ 已生成，且为 **RGB 无透明通道**（带 alpha 会被 App Store 拒） |
| 最低系统版本 | iOS 15.0，且 `Podfile` 用 `post_install` 把**所有 Pod 也钉到 15.0**，避免插件默认 12.0 引发编译失败 |
| Bundle ID | `com.noisemeter.soundMeter`（上架或被占用时改成 `com.zengge.soundmeter`） |
| Xcode 安装脚本 | `scripts/install_xcode.sh`：不依赖 App Store / Homebrew，按 macOS 版本自动选 Xcode，Apple ID 直连下载 |
| 环境安装脚本 | `scripts/mac_setup.sh`：判芯片 → 检查 Xcode → 用 gem 装 CocoaPods → 下载 Flutter 3.47.9 → 配 PATH |
| 一键构建脚本 | `scripts/ios_build.sh run` / `ipa`，自动按正确顺序做环境检查 → `pub get` → `pod install` → 编译 |
| iPad 分享面板崩溃防护 | ✅ 已在 `report_exporter.dart` 传入 `sharePositionOrigin` |

### 路线 A：有 Mac（且 macOS ≥ 13.5）

**先分清一件事，否则一定卡住**：免费 Apple ID 和付费开发者账号能做的事完全不同。

| 你的账号 | 能做什么 | 有效期 |
|---|---|---|
| 免费 Apple ID（在 Xcode 里直接登录） | 只能把 App 装到**用数据线连着的 iPhone**，**导不出 ipa** | 7 天，到期重装 |
| 付费开发者账号（99 美元/年） | 可导出 ipa、TestFlight 分发、上架 App Store | 1 年 |

结论：**免费账号就用「直接装」那条命令，不要执行 `flutter build ipa`**。后者需要「分发证书」，免费账号根本申请不到，会停在 `No signing certificate for "Apple Distribution"` 这一步——这不是配置错误，是苹果的账号策略。

#### 第 0 步 · 把工程传到 Mac

`sound_meter.zip`（约 330KB）需要在 Mac 上，三种传法任选：

- **微信文件传输助手**：Windows 发给自己 → Mac 版微信接收（最省事）
- **U 盘 / 移动硬盘**：直接拷
- **同一局域网**：任一台起个临时 HTTP 服务，另一台浏览器下载

Mac 上解压（双击即可，或命令行）：

```bash
unzip sound_meter.zip && cd sound_meter
```

#### 第 1 步 · 装 Xcode（不用 App Store，不用 Homebrew）

工程里带了 `scripts/install_xcode.sh`。它下载开源的 `xcodes` 工具（通用二进制，Intel 与 Apple 芯片都能跑），用你的 Apple ID 直连苹果服务器下载 Xcode，下完自动解压进 `/Applications`：

```bash
bash scripts/install_xcode.sh          # 自动挑当前系统能装的最高版本
bash scripts/install_xcode.sh 26.3     # 或指定精确版本
bash scripts/install_xcode.sh --list   # 只看你的账号能下哪些版本
```

执行中会要 Apple ID、密码和一条双重认证验证码（密码存进钥匙串，脚本不保存）。

**Intel Mac 的版本上限**（Xcode 27 起只支持 Apple 芯片，Homebrew 也已停止支持 Intel）：

| 你的 macOS | 能装的最高 Xcode | 装到的 iOS SDK |
|---|---|---|
| 26.2 及以上 | 26.6 | iOS 26.5 |
| 15.6 ~ 26.1 | 26.3 | iOS 26.3 |
| 15.3 / 15.4 | 16.4 | iOS 18.4 |
| 15.2 | 16.3 | iOS 18.2 |
| 14.5 ~ 15.1 | 16.2 | iOS 18.2 |
| 14.0 ~ 14.4 | 15.4 | iOS 17.5 |
| 13.5 ~ 13.6 | 15.2 | iOS 17.2 |

脚本会按 `sw_vers` 自动选，你不用记这张表。

装完脚本会自己执行 `xcode-select -s` 与 `xcodebuild -license accept`。验证：

```bash
xcodebuild -version
```

#### 第 2 步 · 装 Flutter 与 CocoaPods

```bash
bash scripts/mac_setup.sh
```

它会判芯片 → 检查 Xcode → 用系统 Ruby 装 CocoaPods（`sudo gem install cocoapods`，最新版装不上会自动退回 1.15.2）→ 下载 Flutter 3.47.9 并配 PATH。全程不依赖 Homebrew。

直到 `flutter doctor` 里 Xcode 与 CocoaPods 都打勾就算齐了。

#### 第 3 步 · 首次先配一次签名（只用做一次）

```bash
cd sound_meter
flutter pub get
open ios/Runner.xcworkspace      # ⚠️ 一定是 xcworkspace，不是 xcodeproj
```

在 Xcode 里：

1. 左侧点 `Runner` → 中间页签 `Signing & Capabilities`；
2. **Team** 下拉选你的 Apple ID（没有就点 `Add an Account` 登录，免费即可）；
3. 勾上 `Automatically manage signing`；
4. 若提示 Bundle Identifier 已被占用，把 `Bundle Identifier` 改成 `com.zengge.soundmeter`（反写域名，全局唯一即可）；
5. 这一步只做一次，之后命令行出包不用再开 Xcode。

#### 第 4 步 · 一条命令出包

工程里带了脚本，它会按正确顺序做环境检查 → 拉依赖 → 装 Pod → 编译：

```bash
cd sound_meter
bash scripts/ios_build.sh run     # 免费 Apple ID：直接装到连着的 iPhone
bash scripts/ios_build.sh ipa     # 付费账号：导出 .ipa
```

> 顺序很重要：交付包里**故意不含** `ios/Flutter/Generated.xcconfig`（在 Windows 上生成的那份写的是 `C:\...` 路径）。脚本第一步跑 `flutter pub get` 把它重新生成为 Mac 路径，再执行 `pod install`。如果你手工操作，也请保持这个先后顺序，否则 `pod install` 会抛出 `FLUTTER_ROOT not found` 之类难懂的错。

#### 第 5 步 · 装到手机

| 方式 | 要求 | 有效期 |
|---|---|---|
| 数据线直装（`ios_build.sh run`） | iPhone 连电脑、手机点「信任此电脑」 | 免费账号 **7 天**，到期重跑一次 |
| TestFlight | 付费账号 | 90 天/版本，可邀请他人测试 |
| Ad Hoc / 上架 | 付费账号 + 设备 UDID / 审核 | 长期 |

首次直装如果提示「不受信任的开发者」：iPhone 上 **设置 → 通用 → VPN与设备管理 → 选中你的 Apple ID → 信任**。

### 路线 B：没有 Mac / Mac 系统太旧（用 GitHub 的免费 macOS 机器）

**当你的 Mac 系统版本低于 macOS 13.5 时装不了新 Xcode，这条路就是唯一解。**
它把「编译」（云端 macOS）和「签名」（Windows + Sideloadly）拆开，Mac 完全不参与。

详细图文步骤见 **[IOS_CLOUD_BUILD.md](IOS_CLOUD_BUILD.md)**，这里是速览：

1. 把 `dist/ios_build_src.zip`（226 KB，已剔除安卓密钥）上传到 GitHub 仓库根目录；
2. 在网页上新建 `.github/workflows/ios-unsigned-ipa.yml`，内容从 zip 里复制；
3. 仓库页 → **Actions** → 左侧选 `Build iOS IPA (unsigned)` → **Run workflow**；
4. 等 15~25 分钟，在该次运行页面底部 **Artifacts** 里下载 `SoundMeter-unsigned-ipa`；
5. 回到 Windows，用 **Sideloadly** 配免费 Apple ID 签名装机（7 天有效期，到期重签）。

工作流已做自适应：zip 摆放、散文件、多一层 `sound_meter/` 目录三种情况都能识别。

### 路线 C：不想折腾签名

只能走 App Store 上架或 TestFlight，两者都需要付费开发者账号（99 美元/年）+ 一台 Mac 做最终归档。没有捷径。

### iOS 高频问题

| 现象 | 原因 | 处理 |
|---|---|---|
| 一点「开始测量」就闪退 | 缺 `NSMicrophoneUsageDescription` | 本工程已加，若你改过 Info.plist 请检查 |
| `pod install` 报最低版本错误 | Podfile 平台版本过低 | 本工程已设 `platform :ios, '15.0'` |
| 编译报 `Building for iOS, but the linked framework was built for iOS Simulator` | 用了模拟器架构的产物 | `flutter clean` 后重来；确认选的是真机/设备而不是模拟器 |
| 提示 `No signing certificate` | 没选 Team | Xcode → Signing & Capabilities → 选 Team |
| 上传 App Store 报「图标含 alpha 通道」 | 图标带透明 | 本工程图标已是 RGB，若你换图标需重新导出无 alpha 版本 |
| iPad 上点分享无反应/崩溃 | popover 缺锚点 | 本工程已传 `sharePositionOrigin` |

---

## 三、改版本号

`pubspec.yaml` 里：

```yaml
version: 1.0.0+1
#        ↑ 版本名（用户看到的）  ↑ 版本号（每次发版必须 +1）
```

---

## 四、高频报错对照表

| 报错 | 原因 | 解决 |
|---|---|---|
| `cmdline-tools component is missing` | 没装 Android 命令行工具 | Android Studio → SDK Manager → SDK Tools → 勾选 Command-line Tools 后重试 |
| `CocoaPods not installed` | 缺 CocoaPods | `sudo gem install cocoapods`（新版 Ruby 装不上就加 `-v 1.15.2`） |
| `Gradle build failed` / 莫名的资源错误 | 构建缓存脏 | `flutter clean && flutter pub get` 后重编 |
| `Execution failed for task ':app:validateSigningRelease'` | key.properties 没配 / 密码错 / 路径不对 | 检查 `android/key.properties` 与 `storeFile` 相对路径 |
| `Keystore was tampered with, or password was incorrect` | 密码错 | 重新确认密码；实在记不住只能换新 keystore（换包名重发） |
| `Provisioning profile doesn't match` | Bundle ID 与描述文件不一致 | Xcode 里改回一致的 Bundle ID，或重新自动签名 |
| `Minimum supported Gradle version is X` | AGP 与 Gradle 版本不匹配 | 改 `android/gradle/wrapper/gradle-wrapper.properties` 里的 `distributionUrl` 版本 |
| iOS 一按开始就闪退 | 缺 `NSMicrophoneUsageDescription` | 补 `Info.plist`（见 README 第四节） |
| 安卓一按开始就没反应 | 缺 `RECORD_AUDIO` 权限 | 补 `AndroidManifest.xml` |
| 读数是 0 或恒定不变 | AGC/降噪被开启，或 PCM 编码选错 | 确认 `encoder: pcm16bits`、三个开关都为 false |
| `Unsupported class file major version` | JDK 版本过高/过低 | 换 JDK 17：`flutter config --jdk-dir "C:\Program Files\Java\jdk-17"` |

---

## 五、边界说明

- 本项目只负责**本地打包**，不做应用商店上架、软著/资质代办、审核结果承诺；
- iOS 的 IPA 必须有开发者证书或 TestFlight 才能装到真机，这是苹果的限制，跟代码无关；
- 安卓 APK 可以直接发给任何人安装（对方需允许"未知来源"）。
