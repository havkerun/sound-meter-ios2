# 苹果版出包 · 不用 Mac 的路线（云端编译 + Windows 签名）

> 适用于：Mac 系统太旧、装不了新 Xcode 的情况。
> 全程 **不需要 Mac、不需要 Xcode、不需要升级系统**，只用一台 Windows 电脑 + 一部 iPhone。
>
> 总耗时：第一次约 40 分钟（其中 15~25 分钟是等云端编译），以后重签只要 5 分钟。
>
> **和你的 Mac 系统版本无关**：云端机器是 macOS 15 + 最新 Xcode，你本机是 macOS 12、11 都一样能跑。

---

## 这条路线为什么能行

```
你的 Windows 电脑                       GitHub 的免费 macOS 机器                你的 iPhone
      │                                        │                                │
      │ ① 上传源码 zip                          │                                │
      ├───────────────────────────────────────► │                                │
      │                                        │ ② 装 Flutter + 编译            │
      │                                        │ ③ 产出未签名 ipa               │
      │ ④ 下载 ipa                              │                                │
      │ ◄───────────────────────────────────────┤                                │
      │ ⑤ Sideloadly 用你的 Apple ID 签名                                        │
      ├────────────────────────────────────────────────────────────────────────►│
      │                                                                        ⑥ 信任证书，开用
```

关键点：**编译**需要 macOS，**签名**不需要。把这两件事拆开，Mac 就可以完全不参与。

---

## 第一部分 · 让 GitHub 帮你编译（约 25 分钟）

### 步骤 1 · 注册 GitHub 账号（约 8 分钟）

打开 <https://github.com/signup>，按顺序填：

| 页面要求 | 怎么填 |
|---|---|
| `Email` | 你的常用邮箱（QQ、163、Gmail 都行），**后面要收验证码** |
| `Password` | 至少 8 位，且包含数字和小写字母 |
| `Username` | 英文+数字，比如 `zengge2026`。会出现在仓库网址里，想好再填 |
| `Email preferences` | 直接点 `Continue`（默认即可） |
| 人机验证 | 按提示点图形/拼图 |

最后一步会往你邮箱发一封 6 位验证码，填进去就注册完成。

**三件容易卡住的事：**

1. **收不到验证码** → 翻垃圾邮件箱；QQ 邮箱经常把 GitHub 邮件归到「垃圾邮件」。
2. **页面打不开或很慢** → 国内网络对 GitHub 时不时限速。换手机热点、或者把电脑 DNS 改成 `223.5.5.5` 再试，不是账号问题。
3. **建仓库时提示要验证手机号** → 新账号偶尔会触发风控，按提示输手机号收个短信即可，免费。

> **必须完成邮箱验证**，否则后面 `Actions` 标签是灰的，点不动。

已经有账号的直接登录，跳到步骤 2。

### 步骤 2 · 建一个仓库

1. 登录后点右上角 `+` → `New repository`
2. `Repository name` 填：`sound-meter-ios`
3. 选 **Public**（公开仓库的编译时长无限；私有仓库每月只有 2000 分钟额度）
4. 下面的 `Add a README file`、`.gitignore`、`license` **全部不勾**
5. 点最下面绿色 `Create repository`

进去后会看到一个空仓库，页面上有一句 `…or upload an existing file` —— 下一歩点它。

> 公开仓库意味着源码可见，但工程里已经剔除了所有签名密钥，没有安全问题。

### 步骤 3 · 上传源码包

1. 在新仓库页面点 `uploading an existing file`（或 `Add file` → `Upload files`）
2. 把 **`ios_build_src.zip`** 拖进虚线框（就这一个文件，226 KB）
3. 等它显示文件名后，点最下面绿色 `Commit changes`

### 步骤 4 · 创建编译配置文件

这个文件决定 GitHub 怎么编译，必须手动建一次。

1. 回到仓库首页，点 `Add file` → `Create new file`
2. 在文件名输入框里**完整输入**（斜杠会自动建文件夹）：

   ```
   .github/workflows/ios-unsigned-ipa.yml
   ```

3. 内容：用记事本打开工程里的 `.github/workflows/ios-unsigned-ipa.yml`
   （也可以直接打开随源码包一起给你的 **`ios-workflow.yml`**），**Ctrl+A 全选 → Ctrl+C 复制**，粘贴到网页的编辑框里
4. 点右上绿色 `Commit changes`

> 找不到那个文件？在解压出来的文件夹里，`.github` 是隐藏文件夹。
> Windows 资源管理器 → 顶部「查看」→ 勾选「隐藏的项目」就能看到。
> 嫌麻烦就用单独给你的 `ios-workflow.yml`，内容完全一样。

### 步骤 5 · 开始编译

1. 点仓库顶部 `Actions` 标签
2. 左侧列表点 `Build iOS IPA (unsigned)`
3. 右侧有黄色提示条，点 `Run workflow` → 再点绿色 `Run workflow` 确认
4. 刷新页面，会出现一条橙点（转圈）的任务，点进去能看实时日志

等待 15~25 分钟。第一次因为要下载 CocoaPods 依赖会比较慢，之后有缓存会快。

**看到绿色 ✓ = 成功。** 中途红了就是失败，把报错那几行发我。

### 步骤 6 · 下载 ipa

1. 点进那次成功的运行记录
2. 拉到页面最底部，`Artifacts` 区域
3. 点 `SoundMeter-unsigned-ipa` 下载（是个 zip）
4. 解压，得到 **`SoundMeter-unsigned.ipa`** —— 这就是你的苹果安装包

---

## 第二部分 · 在 Windows 上签名装机（约 15 分钟）

未签名的 ipa 不能直接装，需要用你自己的 Apple ID 现签一次。免费 Apple ID 就够了。

### 步骤 7 · 装两个软件

| 软件 | 作用 | 下载地址 |
|---|---|---|
| iTunes（**官网 exe 版**，不要微软商店版） | 提供 iPhone 连接驱动 | <https://www.apple.com/itunes/download/win64> |
| Sideloadly | 用 Apple ID 给 ipa 签名并安装 | <https://sideloadly.io/> |

iTunes 装完不用打开。Sideloadly 下载 Windows 版直接运行，免安装。

### 步骤 8 · iPhone 打开开发者模式（iOS 16 及以上必须）

iPhone 上：`设置` → `隐私与安全性` → 拉到最底 `开发者模式` → 打开 → 重启手机 → 重启后解锁，弹窗点「打开」。

### 步骤 9 · 签名安装

1. 数据线把 iPhone 连到电脑，手机上点「信任此电脑」
2. 打开 Sideloadly，顶部 `iOS device` 下拉里应该能看到你的 iPhone
3. 把 `SoundMeter-unsigned.ipa` **拖进 Sideloadly 窗口**
4. `Apple ID` 一栏填你的 Apple ID（Apple 账号邮箱）
5. 点 `Start`
6. 弹出输入密码：填 Apple ID 密码
   - 如果开了双重认证，可能要求「App 专用密码」——
     去 <https://appleid.apple.com> → 登录 → `登录与安全` → `App 专用密码` → 生成一个填进去
7. 进度条走完，手机上出现「曾哥声压测量」

### 步骤 10 · 信任开发者

第一次点 App 会提示「不受信任的开发者」。

iPhone 上：`设置` → `通用` → `VPN 与设备管理` → 点你的 Apple ID（邮箱）→ `信任 "..."` → 再点一次信任。

回到桌面，点开就能用了。

---

## 必须知道的限制

| 项目 | 限制 |
|---|---|
| 有效期 | 免费 Apple ID 签的包 **7 天后失效**，App 打不开，需重新跑步骤 9（源码不用重编，ipa 留着就行） |
| App 数量 | 一个免费账号同时最多 3 个自签 App |
| 数据 | 重签是覆盖安装，**App 内的测量记录不会丢**（数据库在沙盒里保留） |
| 彻底解决 | 想要 1 年有效期，需加入 Apple Developer Program（688 元/年），或用 TestFlight 分发 |

---

## 常见问题

**Q：Actions 页面一直转圈打不开？**
GitHub 在国内偶尔会慢。换个网络（手机热点）或过几分钟再试，不是配置问题。

**Q：编译报 `flutter-version 3.47.9 not found`？**
打开 `.github/workflows/ios-unsigned-ipa.yml`，把 `flutter-version: '3.47.9'` 改成 `channel: stable` 那一行走默认最新版，再重新 Run workflow。

**Q：编译报 `Xcode 16.x is required` 或 `requires a newer version of Xcode`？**
说明 GitHub 那台机器上的 Xcode 比 Flutter 3.47.9 要求的还旧。把工作流第一段的
`runs-on: macos-15` 改成 `runs-on: macos-26`（若报错说该镜像不存在，就改成 `macos-latest`），再 Run workflow。

**Q：编译报 `Podfile` 或 `pod install` 失败？**
把日志里 `[!]` 开头的那几行发我，通常是某个插件的 iOS 最低版本不匹配，我改 Podfile。

**Q：编译成功但手机装不上，报 `Unable to install`？**
先确认 iPhone 系统 ≥ iOS 15.0（App 的最低要求）。低于 15 就装不了。

**Q：Sideloadly 报 `AMFI` / `Unable to sign`？**
在 Sideloadly 里勾上 `Change Bundle ID`，填一个别人没用过的，比如 `com.zengge.noisemeter2`。

**Q：手机连不上 Sideloadly？**
换一根**能传数据**的线（很多充电线只有电没有数据），或换 USB 口，重新点手机上「信任此电脑」。

---

## 想改代码后重新出包

改完代码 → 重新生成 `ios_build_src.zip` → GitHub 仓库里删掉旧 zip 传新的（`Add file` → `Upload files` 会覆盖同名文件）→ Actions 再 Run 一次。

---

*文档随工程一起维护。编译脚本见 `.github/workflows/ios-unsigned-ipa.yml`。*
