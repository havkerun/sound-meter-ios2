# 曾哥声压测量（sound_meter）

用手机麦克风测环境声压级（dB SPL）的跨平台 App，一套 Flutter 代码同时出安卓 APK 和苹果 IPA。

> 定位：日常噪声判断与沟通说明用的**参考级工具**，带校准功能，校准后读数接近专业声级计；不作为法定计量或法律取证依据。

---

## 一、已实现的功能（V1 全部做完）

| 功能 | 说明 |
|---|---|
| 实时声压级 | 大号数字 + 分段柱状条，约 16 帧/秒刷新 |
| A / C / Z 计权 | A 模拟人耳（默认）、C 保留低频、Z 平直 |
| 快 / 慢时间计权 | F = 125ms、S = 1s，按 IEC 61672 指数平均 |
| 最大 / 最小 / 等效声级 | 实时统计，Leq 为能量平均 |
| **实时曲线** | 测量中显示最近 60 秒的声级走势 |
| **时间历程曲线** | 每秒一个测点（Leq,1s），详情页看全段走势 |
| **统计声级 L10/L50/L90** | L10 看吵闹时段、L90 看背景噪声、两者之差看起伏 |
| **测量报告导出** | 一键生成白色底报告卡片图片，直接发微信给物业/房东 |
| 麦克风校准 | 填参考仪器读数，自动算偏移并全局生效 |
| 测量记录 | 本地 SQLite 存储，列表 / 详情 / 删除 / 清空 |
| 等级解释 | 五档颜色 + 人话说明 + 听力风险提示 |
| 屏幕常亮 | 测量时不息屏 |
| 算法自检 | `flutter test` 校验计权频响与 dB 换算 |

## 二、目录结构

```
sound_meter/
├─ lib/
│  ├─ main.dart                     入口 + 底部两个 Tab（测量 / 记录）
│  ├─ theme.dart                    配色与主题
│  ├─ core/
│  │  ├─ audio/mic_source.dart      麦克风采集（record 插件封装，可替换）
│  │  ├─ dsp/biquad.dart            二阶 IIR 滤波器
│  │  ├─ dsp/weighting_filter.dart  A / C / Z 计权滤波器（IEC 61672）
│  │  ├─ dsp/sound_level_meter.dart 声压级计算核心（RMS → dB → 时间计权 → Leq/统计声级/时间历程）
│  │  ├─ level_zone.dart            分贝等级分区与文案
│  │  └─ report_exporter.dart       报告截图 + 系统分享
│  ├─ data/
│  │  ├─ measurement.dart           记录数据模型（含曲线、L10/L50/L90）
│  │  ├─ measurement_dao.dart       SQLite 读写（v2 迁移）
│  │  └─ settings_store.dart        校准偏移 / 偏好设置（SharedPreferences）
│  ├─ state/meter_controller.dart   测量流程总控（ChangeNotifier）
│  └─ ui/
│     ├─ home_page.dart             测量页（含实时曲线）
│     ├─ calibration_page.dart      校准页
│     ├─ history_page.dart          记录列表
│     ├─ detail_page.dart           记录详情（曲线 + 统计声级）
│     ├─ report_page.dart           测量报告（可导出图片）
│     ├─ settings_page.dart         设置页
│     └─ widgets/                   卡片、柱状条、曲线图
├─ test/dsp_test.dart               算法自检
├─ android/                         安卓工程（权限、图标、签名已配好，已产出 APK）
├─ ios/                             苹果工程（显示名、麦克风说明、图标已配好，需 macOS 编译）
└─ .github/workflows/               无 Mac 时用 GitHub 云端 macOS 编 iOS 包
```

## 三、跑起来（Windows / macOS 通用）

本项目已带 `android/` 平台外壳、应用图标、麦克风权限与发布签名配置（详见 `BUILD.md` 第零节），**不需要再执行 `flutter create`**。

### 1. 装 Flutter

去 https://docs.flutter.dev/get-started/install 安装 Flutter SDK（要求 **3.22 或更高**），装完在终端确认：

```bash
flutter --version
flutter doctor
```

`flutter doctor` 里 Android toolchain 打勾、或 macOS 上 Xcode 打勾，才能打包。

### 2. 拉依赖并运行

```bash
flutter pub get
flutter devices          # 看有没有连上手机/模拟器
flutter run
```

### 3. 跑算法自检

```bash
flutter test
```

## 四、平台配置说明（已内置，仅作参考）

### 安卓：`android/app/src/main/AndroidManifest.xml`

在 `<manifest>` 标签内、`<application>` 之前加一行麦克风权限：

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
```

同时确认 `android/app/build.gradle`（新版是 `build.gradle.kts`）里的 `minSdk` 不低于 **23**：

```gradle
defaultConfig {
    minSdk 23
    ...
}
```

### 苹果：`ios/Runner/Info.plist`

在 `<dict>` 内加麦克风用途说明（缺这条，iOS 上按开始会直接闪退）：

```xml
<key>NSMicrophoneUsageDescription</key>
<string>需要使用麦克风测量环境声压级</string>
```

若 `pod install` 报最低版本错误，把 `ios/Podfile` 第一行的 `platform :ios, '12.0'` 取消注释即可。

## 五、算法是怎么算的（这是本项目的核心）

```
PCM16 采样 → 归一化到 [-1,1] → 频率计权滤波(A/C/Z) → 求均方 → 时间计权平滑
           → dB = 10·log10(p²) + 满量程参考值 + 校准偏移
```

几个关键点：

**1. 满量程参考值（默认 120 dB）**
数字满量程（0 dBFS）对应多少真实声压，取决于手机麦克风灵敏度。典型 MEMS 麦克风约 −26 dBFS @ 94 dB SPL，反推 0 dBFS ≈ 120 dB SPL。各机型差异可达 ±10 dB，这正是校准存在的意义。

**2. 计权滤波器**
按 IEC 61672-1 的模拟原型设计，拆成 4 个一/二阶节分别做**带频率预畸变的双线性变换**，再在 1 kHz 归一到 0 dB。实测（48 kHz）：

| 频率 | 20 Hz | 100 Hz | 1 kHz | 4 kHz | 8 kHz | 10 kHz | 12.5 kHz | 16 kHz |
|---|---|---|---|---|---|---|---|---|
| 误差(dB) | 0.0 | 0.1 | 0.0 | 0.3 | 0.8 | 0.6 | 0.1 | 3.0 |

即 20 Hz–12.5 kHz 内误差 ≤ 0.8 dB，优于 IEC 61672 的 2 级声级计容差；16 kHz 附近因逼近奈奎斯特频率有约 3 dB 偏差（手机麦克风本身在该频段也已衰减十几 dB，实际影响可忽略）。

以上数字不是估算，是直接跑本项目 `lib/core/dsp/` 里的真实代码、逐频点与 IEC 标准曲线对比得到的（`flutter test` 里也有对应断言）。

**3. 时间计权**
`p²_bar = (1-α)·p²_bar + α·p²`，其中 `α = 1 - e^(-dt/τ)`，F 取 τ=125ms，S 取 τ=1s。

**4. Leq（等效连续声级）**
按能量平均：`Leq = 10·log10( Σ p²·dt / Σdt )`，比"平均读数"更符合人对噪声的整体感受。

**5. 为什么必须关掉 AGC / 降噪**
`mic_source.dart` 里把 `autoGain / echoCancel / noiseSuppress` 全设为 false。这三个功能会自动放大信号、抹掉频谱细节，一旦开启，读数会随环境"自我修正"，测出来的就不是真实声压了。

## 六、校准怎么用

1. 借/买一台已校准的声级计（或用校准器输出的标准声源，如 94 dB @ 1 kHz）；
2. 手机和仪器放在**同一位置、同一朝向**，注意别用手挡住麦克风孔；
3. 在 App 里点「校准 → 开始采集」，等读数稳定；
4. 把仪器上的读数填进「参考仪器读数」，点「保存校准」。

偏移只对当前这台手机有效。**换手机、加手机壳、外接麦克风后都要重新校准。**

## 七、已知限制（写进免责声明里的那些）

- 手机麦克风量程约 30–120 dB，超过会削波失真，读数会"卡"在某个上限；
- 各机型麦克风频响不同，尤其低频段差异大，A 计权读数个体差异可能达 ±5 dB；
- 未校准时读数只能看相对变化，绝对值不可信；
- iOS/Android 系统可能对录音流做轻微的重采样，`record` 插件不保证实际采样率严格等于请求值（本项目请求 48 kHz，绝大多数机型支持）；
- 前后台切换、来电等系统事件可能中断采集，V1 未做后台常驻。

## 八、V2 新增的三样东西

### 1. 时间历程曲线

测量过程中每 1 秒切一个 `Leq,1s` 测点，存在 `series` 里：
- 首页：测量中显示最近 60 秒的实时走势（高度只有 88px，不挤占主读数）；
- 详情页/报告：显示全段曲线，虚线段是整段的 Leq。

曲线用 `CustomPainter` 自己画（`ui/widgets/level_chart.dart`），没有引图表库——保安装包体积，也方便改样式。超过 400 个点时按桶取平均降采样，避免一次画上万个点掉帧。

### 2. 统计声级 L10 / L50 / L90

把每秒的测点升序排序后按分位取：
- **L10**：有 10% 的时间超过该值 → 反映"最吵的那一段"
- **L50**：中位数
- **L90**：有 90% 的时间超过该值 → 反映**背景噪声**

样本少于 10 个点时不计算（用 8 个点算 10% 分位没有意义），界面显示 `—`。

> 实际用法：L10 与 L90 差距大（比如 75 和 45），说明噪声是"一阵一阵"的（装修、车流、叫卖）；两者接近，说明是持续性的背景噪声（空调外机、风机）。

### 3. 测量报告导出

详情页 → 右上角图标或底部「生成测量报告」→ 报告页 → 「生成图片并分享」。

报告卡片包含：时间、时长、Leq 大字、曲线、最大/最小/L10/L50/L90、计权与校准参数、GB 3096 居民区限值参考、免责声明。

实现方式是用 `RepaintBoundary` 把卡片渲染成 3 倍分辨率 PNG（`core/report_exporter.dart`），再调 `share_plus` 走系统分享面板。**没有用 PDF**，因为 PDF 里显示中文必须打包中文字体（好几 MB 且容易乱码），截图这条路中文绝对正常、还能直接发微信。

### 数据库迁移

记录表从 v1 升到 v2，新增 `l10_db / l50_db / l90_db / series` 四列。`onUpgrade` 里用 `ALTER TABLE ADD COLUMN` 补列，**不会清空旧记录**（旧记录的这四项为 null，界面显示 `—`，曲线区显示"没有曲线数据"）。

## 九、还能接着做（V3）

1/3 倍频程频谱分析（定位噪声频率特征，比如判断是低频嗡嗡声还是高频尖锐声）、测量时附带录音片段/现场照片/GPS、后台持续测量与超标提醒、云端同步与多点噪声地图。

---

打包成 APK / IPA 的完整步骤见 **[BUILD.md](BUILD.md)**。
