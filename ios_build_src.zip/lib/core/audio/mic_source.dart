import 'dart:async';
import 'dart:typed_data';

import 'package:record/record.dart';

/// 麦克风采集抽象。
///
/// 之所以抽一层接口：万一某个机型/某个 record 版本的行为不一致（尤其是
/// 原始 PCM 与 AGC 的处理），只要换掉这里的实现，上层计算与界面完全不用动。
abstract class MicSource {
  Future<bool> hasPermission();
  Future<Stream<Int16List>> start({int sampleRate});
  Future<void> stop();
  Future<void> dispose();
}

/// 基于 record 插件的实现。
///
/// 关键参数说明（这几个参数直接决定测量准不准）：
/// - encoder: pcm16bits —— 必须拿原始 PCM，不能要 AAC/Opus，那些有损压缩会改变幅值
/// - sampleRate: 48000 —— 固定的高采样率，覆盖人耳全频段；计权滤波器按实际采样率设计
/// - numChannels: 1 —— 单声道就够，省一半算力
/// - autoGain / echoCancel / noiseSuppress: false —— 这三个是"美颜"，
///   会自动改变信号幅值与频谱，测声压时必须全部关掉，否则读数会漂
class RecordMicSource implements MicSource {
  final AudioRecorder _recorder = AudioRecorder();
  StreamSubscription<Uint8List>? _sub;
  StreamController<Int16List>? _controller;

  @override
  Future<bool> hasPermission() => _recorder.hasPermission();

  @override
  Future<Stream<Int16List>> start({int sampleRate = 48000}) async {
    await stop();

    final controller = StreamController<Int16List>.broadcast();
    _controller = controller;

    final RecordConfig config = RecordConfig(
      encoder: AudioEncoder.pcm16bits,
      sampleRate: sampleRate,
      numChannels: 1,
      autoGain: false,
      echoCancel: false,
      noiseSuppress: false,
    );

    final stream = await _recorder.startStream(config);
    _sub = stream.listen(
      (data) {
        final pcm = _toInt16(data);
        if (pcm.isNotEmpty) controller.add(pcm);
      },
      onError: (Object e) => controller.addError(e),
    );
    return controller.stream;
  }

  @override
  Future<void> stop() async {
    await _sub?.cancel();
    _sub = null;
    try {
      await _recorder.stop();
    } catch (_) {
      // 未在录制时调用 stop 会抛异常，忽略即可
    }
    if (_controller != null && !_controller!.isClosed) {
      await _controller!.close();
    }
    _controller = null;
  }

  @override
  Future<void> dispose() async {
    await stop();
    await _recorder.dispose();
  }

  /// Uint8List（小端 PCM16）→ Int16List
  static Int16List _toInt16(Uint8List bytes) {
    final count = bytes.length ~/ 2;
    if (count == 0) return Int16List(0);
    final out = Int16List(count);
    final bd = ByteData.sublistView(bytes);
    for (var i = 0; i < count; i++) {
      out[i] = bd.getInt16(i * 2, Endian.little);
    }
    return out;
  }
}
