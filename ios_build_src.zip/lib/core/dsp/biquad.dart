import 'dart:math' as math;

/// 一个标准的二阶 IIR 滤波器（Direct Form I）。
///
/// 系数约定：a0 已归一化为 1，所以传递函数是
///   H(z) = (b0 + b1·z⁻¹ + b2·z⁻²) / (1 + a1·z⁻¹ + a2·z⁻²)
///
/// 之所以用 Direct Form I（而不是转置型），是因为它的状态变量直观、
/// 便于 reset()，在移动端 48kHz 实时流上性能完全够用。
class Biquad {
  final double b0;
  final double b1;
  final double b2;
  final double a1;
  final double a2;

  double _x1 = 0.0;
  double _x2 = 0.0;
  double _y1 = 0.0;
  double _y2 = 0.0;

  Biquad(this.b0, this.b1, this.b2, this.a1, this.a2);

  /// 逐样本处理。热路径，不要在这里分配对象。
  double process(double x) {
    final y = b0 * x + b1 * _x1 + b2 * _x2 - a1 * _y1 - a2 * _y2;
    _x2 = _x1;
    _x1 = x;
    _y2 = _y1;
    _y1 = y;
    return y;
  }

  /// 输入增益缩放（用于把整条链在 1kHz 处归一到 0 dB）。
  Biquad scaled(double g) => Biquad(b0 * g, b1 * g, b2 * g, a1, a2);

  void reset() {
    _x1 = 0.0;
    _x2 = 0.0;
    _y1 = 0.0;
    _y2 = 0.0;
  }

  /// 在频率 f 处的幅度响应（dB）。用于自检与校准时的频响验证。
  double magnitudeDb(double f, double fs) {
    final w = 2 * math.pi * f / fs;
    final c1 = math.cos(w);
    final s1 = -math.sin(w);
    final c2 = math.cos(2 * w);
    final s2 = -math.sin(2 * w);

    final nr = b0 + b1 * c1 + b2 * c2;
    final ni = b1 * s1 + b2 * s2;
    final dr = 1 + a1 * c1 + a2 * c2;
    final di = a1 * s1 + a2 * s2;

    final den = dr * dr + di * di;
    if (den < 1e-30) return -300.0;
    final rr = (nr * dr + ni * di) / den;
    final ii = (ni * dr - nr * di) / den;
    final m2 = rr * rr + ii * ii;
    // 注意：dart:math 没有 log10，必须用 log(x)/ln10
    return 10 * (math.log(m2 < 1e-30 ? 1e-30 : m2) / math.ln10);
  }
}
