import 'dart:math' as math;
import 'dart:typed_data';

import 'weighting_filter.dart';

/// 时间计权（IEC 61672 的 F / S）。
/// - fast：时间常数 125ms，接近人耳对连续声的响应
/// - slow：时间常数 1s，读数更稳，适合读“平均感觉”
enum TimeWeighting { fast, slow }

extension TimeWeightingLabel on TimeWeighting {
  String get label => this == TimeWeighting.fast ? '快 (F)' : '慢 (S)';
  double get tauSeconds => this == TimeWeighting.fast ? 0.125 : 1.0;
}

/// 一次处理的结果快照。
class LevelReading {
  /// 当前瞬时声压级（已含校准偏移），单位 dB
  final double db;

  /// 自测量开始以来的最大值 / 最小值
  final double maxDb;
  final double minDb;

  /// 等效连续声级（能量平均），单位 dB
  final double leqDb;

  /// 已测量时长
  final double elapsedSeconds;

  const LevelReading({
    required this.db,
    required this.maxDb,
    required this.minDb,
    required this.leqDb,
    required this.elapsedSeconds,
  });

  static const LevelReading zero = LevelReading(
    db: 0,
    maxDb: 0,
    minDb: 0,
    leqDb: 0,
    elapsedSeconds: 0,
  );
}

/// 统计声级。L10 = 有 10% 的时间声级超过该值（反映"峰值侧"），
/// L90 = 有 90% 的时间超过该值（反映"背景噪声"）。
class SoundStats {
  final double? l10;
  final double? l50;
  final double? l90;

  /// 参与统计的秒数（样本不足时统计无意义，会返回 null）
  final int seconds;

  const SoundStats({
    required this.l10,
    required this.l50,
    required this.l90,
    required this.seconds,
  });

  static const SoundStats empty =
      SoundStats(l10: null, l50: null, l90: null, seconds: 0);

  bool get valid => l10 != null;
}

/// 声压级计算核心。
///
/// 计算链路：
///   PCM16 样本 → 归一化到 [-1,1] → 频率计权（A/C/Z）→ 平方求均值 → 时间计权
///   → 10·log10(p²) + 满量程参考值 + 校准偏移 = dB SPL
///
/// 关于"满量程参考值"（fullScaleSplDb，默认 120dB）：
///   数字满量程（0 dBFS）对应的实际声压取决于手机麦克风灵敏度，
///   典型 MEMS 麦克风约 -26 dBFS @ 94 dB SPL，推算 0 dBFS ≈ 120 dB SPL。
///   各机型差异很大，这正是必须提供"校准偏移"的原因。
class SoundLevelMeter {
  final int sampleRate;

  /// 校准偏移（dB），用户校准后写入，直接加到结果上。
  double calibrationOffsetDb;

  /// 0 dBFS 对应的声压级。一般不用改，校准偏移会把这个误差一并吸收。
  final double fullScaleSplDb;

  FrequencyWeighting weighting;
  TimeWeighting timeWeighting;

  /// 时间历程的采样间隔（秒）。1 秒一个点 = 标准的 Leq,1s 时间历程。
  final double sliceSeconds;

  /// 时间历程最多保留多少个点，防止超长测量把内存吃穿
  final int maxSlices;

  WeightingFilter _filter;

  /// 时间计权后的均方值（归一化域，满量程正弦约为 0.5）
  double _p2Bar = 0.0;
  bool _hasHistory = false;

  /// 能量累计，用于整体 Leq（平方和 × 时间）
  double _energySum = 0.0;
  double _elapsed = 0.0;

  /// 当前切片内的能量累计
  double _sliceEnergy = 0.0;
  double _sliceTime = 0.0;

  /// 每秒一个的 Leq 序列，用于画时间历程曲线和算统计声级
  final List<double> _series = <double>[];

  double _maxDb = double.negativeInfinity;
  double _minDb = double.infinity;

  /// 低于该值视为静音底噪，避免 log(0) 得到 -Infinity
  static const double _floorDb = 0.0;

  SoundLevelMeter({
    required this.sampleRate,
    this.calibrationOffsetDb = 0.0,
    this.fullScaleSplDb = 120.0,
    this.weighting = FrequencyWeighting.a,
    this.timeWeighting = TimeWeighting.fast,
    this.sliceSeconds = 1.0,
    this.maxSlices = 20000,
  }) : _filter = WeightingFilter(weighting, sampleRate.toDouble());

  FrequencyWeighting get currentWeighting => weighting;

  /// 时间历程序列（只读！不要往里面 add/remove）。
  /// 返回内部引用而不是副本，是为了避免每秒都复制一次长列表。
  List<double> get series => _series;

  /// 重置统计，开始新一次测量。
  void reset() {
    _filter.reset();
    _p2Bar = 0.0;
    _hasHistory = false;
    _energySum = 0.0;
    _elapsed = 0.0;
    _sliceEnergy = 0.0;
    _sliceTime = 0.0;
    _series.clear();
    _maxDb = double.negativeInfinity;
    _minDb = double.infinity;
  }

  /// 切换计权方式（会重置滤波器状态，避免切换瞬间跳数）。
  void setWeighting(FrequencyWeighting w) {
    if (w == weighting) return;
    weighting = w;
    _filter = WeightingFilter(w, sampleRate.toDouble());
    // 滤波器换了，旧的平滑值不再可比，重新起算平滑但保留统计
    _p2Bar = 0.0;
    _hasHistory = false;
  }

  void setTimeWeighting(TimeWeighting t) {
    timeWeighting = t;
  }

  /// 处理一块 PCM16 样本，返回本块的读数。
  LevelReading processChunk(Int16List samples) {
    if (samples.isEmpty) return _snapshot();

    var sumSq = 0.0;
    final sections = _filter;
    for (var i = 0; i < samples.length; i++) {
      // 32768 而不是 32767：让负半轴与正半轴对称
      final x = samples[i] / 32768.0;
      final y = sections.process(x);
      sumSq += y * y;
    }

    final blockP2 = sumSq / samples.length;
    final dt = samples.length / sampleRate;

    // 指数时间计权：alpha = 1 - e^(-dt/tau)
    final tau = timeWeighting.tauSeconds;
    final alpha = 1 - math.exp(-dt / tau);
    if (_hasHistory) {
      _p2Bar = (1 - alpha) * _p2Bar + alpha * blockP2;
    } else {
      _p2Bar = blockP2;
      _hasHistory = true;
    }

    final db = _toDb(_p2Bar);

    _energySum += blockP2 * dt;
    _elapsed += dt;
    if (db > _maxDb) _maxDb = db;
    if (db < _minDb) _minDb = db;

    // 累积到 1 秒就切出一个 Leq,1s 点（时间历程 + 统计声级的原料）
    _sliceEnergy += blockP2 * dt;
    _sliceTime += dt;
    if (_sliceTime >= sliceSeconds) {
      if (_series.length < maxSlices) {
        _series.add(_toDb(_sliceEnergy / _sliceTime));
      }
      _sliceEnergy = 0.0;
      _sliceTime = 0.0;
    }

    return _snapshot();
  }

  /// 统计声级 L10 / L50 / L90。
  /// 样本少于 10 个时不给出结果 —— 用 8 个点算"10% 分位"没有意义。
  SoundStats computeStats() {
    if (_series.length < 10) {
      return SoundStats(
        l10: null,
        l50: null,
        l90: null,
        seconds: _series.length,
      );
    }
    final sorted = List<double>.of(_series)..sort(); // 升序
    double pick(double exceedFraction) {
      // 升序排列后，L10 落在 90% 位置
      final idx = ((1 - exceedFraction) * (sorted.length - 1)).round();
      return sorted[idx.clamp(0, sorted.length - 1)];
    }

    return SoundStats(
      l10: pick(0.10),
      l50: pick(0.50),
      l90: pick(0.90),
      seconds: _series.length,
    );
  }

  LevelReading _snapshot() {
    final leq = _elapsed > 0 ? _toDb(_energySum / _elapsed) : _floorDb;
    return LevelReading(
      db: _hasHistory ? _toDb(_p2Bar) : _floorDb,
      maxDb: _maxDb.isFinite ? _maxDb : _floorDb,
      minDb: _minDb.isFinite ? _minDb : _floorDb,
      leqDb: leq,
      elapsedSeconds: _elapsed,
    );
  }

  double _toDb(double p2) {
    if (p2 <= 1e-14) return _floorDb;
    // dart:math 没有 log10，用 log/ln10 换算
    return 10 * (math.log(p2) / math.ln10) + fullScaleSplDb + calibrationOffsetDb;
  }
}
