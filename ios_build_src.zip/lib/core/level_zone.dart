import 'package:flutter/material.dart';

/// 分贝等级分区。用来把"数字"翻译成"人话"，这是普通用户最需要的部分。
enum LevelZone {
  quiet(0, '很安静', '接近图书馆或深夜卧室', Color(0xFF1D9E75)),
  normal(40, '正常', '日常交谈水平，舒适区', Color(0xFF639922)),
  loud(60, '偏吵', '可能影响专注与休息', Color(0xFFEF9F27)),
  veryLoud(75, '很吵', '长时间停留会疲劳，建议缩短时间', Color(0xFFD85A30)),
  dangerous(85, '危险', '建议佩戴护耳并尽快离开', Color(0xFFE24B4A));

  const LevelZone(this.dbFrom, this.label, this.tip, this.color);

  final double dbFrom;
  final String label;
  final String tip;
  final Color color;

  static LevelZone of(double db) {
    var zone = LevelZone.quiet;
    for (final z in LevelZone.values) {
      if (db >= z.dbFrom) zone = z;
    }
    return zone;
  }

  /// 相对听力风险的一句话（比 zone.tip 更"结论性"）
  String get riskHint => switch (this) {
        LevelZone.quiet => '对听力无风险',
        LevelZone.normal => '长时间停留也无风险',
        LevelZone.loud => '每天累计 8 小时以上才需要留意',
        LevelZone.veryLoud => '每天累计建议不超过 8 小时',
        LevelZone.dangerous => '每天累计建议不超过 30 分钟',
      };
}
