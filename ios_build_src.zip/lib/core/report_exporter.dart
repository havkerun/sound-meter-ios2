import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// 把界面上的报告卡片截成 PNG 并分享出去。
///
/// 为什么用"截图"而不是生成 PDF：PDF 里要显示中文必须嵌入中文字体文件
/// （动辄好几 MB，还容易乱码）；而截图走的是系统渲染，中文、图标全都正常，
/// 生成的 PNG 也能直接发微信给对方看。
class ReportExporter {
  /// 截取 [key] 对应的 widget，返回生成的文件。
  static Future<File> capture(
    GlobalKey key, {
    double pixelRatio = 3.0,
  }) async {
    final object = key.currentContext?.findRenderObject();
    if (object is! RenderRepaintBoundary) {
      throw StateError('报告还没有渲染完成，请稍后再试');
    }
    final ui.Image image = await object.toImage(pixelRatio: pixelRatio);
    final ByteData? data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw StateError('图像编码失败');

    final dir = await getTemporaryDirectory();
    final name = 'noise_report_${DateTime.now().millisecondsSinceEpoch}.png';
    final file = File(p.join(dir.path, name));
    await file.writeAsBytes(data.buffer.asUint8List(), flush: true);
    return file;
  }

  /// 截图并调起系统分享面板（微信、邮件、文件管理等都能选）。
  ///
  /// [sharePositionOrigin] 在 iPad 上是必须的：iPad 的分享面板是 popover，
  /// 没有锚点矩形会直接抛异常。这里用报告卡片自身的全局矩形当锚点。
  static Future<void> share(GlobalKey key, {String? text}) async {
    final file = await capture(key);

    Rect? origin;
    final renderObject = key.currentContext?.findRenderObject();
    if (renderObject is RenderBox && renderObject.hasSize) {
      origin = renderObject.localToGlobal(Offset.zero) & renderObject.size;
    }

    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'image/png')],
      text: text ?? '环境噪声测量报告',
      sharePositionOrigin: origin,
    );
  }
}
