import 'dart:convert';

import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';

/// 一条测量记录。
class Measurement {
  final int? id;
  final DateTime startTime;
  final DateTime endTime;

  /// 等效连续声级（能量平均），本次测量的"代表值"
  final double leqDb;
  final double maxDb;
  final double minDb;

  /// 统计声级：L10 反映峰值侧、L90 反映背景噪声。样本不足时为 null。
  final double? l10Db;
  final double? l50Db;
  final double? l90Db;

  /// 时间历程：每秒一个 Leq 值（dB）
  final List<double> series;

  final FrequencyWeighting weighting;
  final TimeWeighting timeWeighting;

  /// 测量时使用的校准偏移，记录下来方便日后追溯
  final double calibrationOffsetDb;

  const Measurement({
    this.id,
    required this.startTime,
    required this.endTime,
    required this.leqDb,
    required this.maxDb,
    required this.minDb,
    this.l10Db,
    this.l50Db,
    this.l90Db,
    this.series = const <double>[],
    required this.weighting,
    required this.timeWeighting,
    required this.calibrationOffsetDb,
  });

  Duration get duration => endTime.difference(startTime);

  String get durationText {
    final d = duration;
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    if (h > 0) return '$h时$m分$s秒';
    if (m > 0) return '$m分$s秒';
    return '$s秒';
  }

  Measurement copyWith({int? id}) => Measurement(
        id: id ?? this.id,
        startTime: startTime,
        endTime: endTime,
        leqDb: leqDb,
        maxDb: maxDb,
        minDb: minDb,
        l10Db: l10Db,
        l50Db: l50Db,
        l90Db: l90Db,
        series: series,
        weighting: weighting,
        timeWeighting: timeWeighting,
        calibrationOffsetDb: calibrationOffsetDb,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'start_ms': startTime.millisecondsSinceEpoch,
        'end_ms': endTime.millisecondsSinceEpoch,
        'leq_db': leqDb,
        'max_db': maxDb,
        'min_db': minDb,
        'l10_db': l10Db,
        'l50_db': l50Db,
        'l90_db': l90Db,
        // 曲线点可能上千个，存成 JSON 数组字符串最省事
        'series': series.isEmpty ? null : jsonEncode(series),
        'weighting': weighting.name,
        'time_weighting': timeWeighting.name,
        'calib_offset': calibrationOffsetDb,
      };

  static Measurement fromMap(Map<String, Object?> m) => Measurement(
        id: m['id'] as int?,
        startTime:
            DateTime.fromMillisecondsSinceEpoch(m['start_ms'] as int? ?? 0),
        endTime: DateTime.fromMillisecondsSinceEpoch(m['end_ms'] as int? ?? 0),
        leqDb: (m['leq_db'] as num?)?.toDouble() ?? 0,
        maxDb: (m['max_db'] as num?)?.toDouble() ?? 0,
        minDb: (m['min_db'] as num?)?.toDouble() ?? 0,
        l10Db: (m['l10_db'] as num?)?.toDouble(),
        l50Db: (m['l50_db'] as num?)?.toDouble(),
        l90Db: (m['l90_db'] as num?)?.toDouble(),
        series: _decodeSeries(m['series'] as String?),
        weighting: FrequencyWeighting.values.firstWhere(
          (e) => e.name == m['weighting'],
          orElse: () => FrequencyWeighting.a,
        ),
        timeWeighting: TimeWeighting.values.firstWhere(
          (e) => e.name == m['time_weighting'],
          orElse: () => TimeWeighting.fast,
        ),
        calibrationOffsetDb: (m['calib_offset'] as num?)?.toDouble() ?? 0,
      );

  static List<double> _decodeSeries(String? raw) {
    if (raw == null || raw.isEmpty) return const <double>[];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) => (e as num).toDouble()).toList();
    } catch (_) {
      // 老版本或被手工改坏的数据，直接当作没有曲线，不要让整页崩掉
      return const <double>[];
    }
  }
}
