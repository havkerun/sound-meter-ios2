import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'measurement.dart';

/// 测量记录的本地存储（SQLite）。
///
/// 版本历史：
///   v1 基础字段
///   v2 增加时间历程序列 series 与统计声级 l10/l50/l90
class MeasurementDao {
  static const int _version = 2;

  Database? _db;

  Future<Database> _open() async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    final path = p.join(dir, 'sound_meter.db');
    _db = await openDatabase(
      path,
      version: _version,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE measurements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_ms INTEGER NOT NULL,
            end_ms INTEGER NOT NULL,
            leq_db REAL NOT NULL,
            max_db REAL NOT NULL,
            min_db REAL NOT NULL,
            l10_db REAL,
            l50_db REAL,
            l90_db REAL,
            series TEXT,
            weighting TEXT NOT NULL,
            time_weighting TEXT NOT NULL,
            calib_offset REAL NOT NULL
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_measurements_end ON measurements(end_ms DESC)',
        );
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        // 从 v1 升上来：补列，不删数据
        if (oldVersion < 2) {
          await db.execute('ALTER TABLE measurements ADD COLUMN l10_db REAL');
          await db.execute('ALTER TABLE measurements ADD COLUMN l50_db REAL');
          await db.execute('ALTER TABLE measurements ADD COLUMN l90_db REAL');
          await db.execute('ALTER TABLE measurements ADD COLUMN series TEXT');
        }
      },
    );
    return _db!;
  }

  Future<int> insert(Measurement m) async {
    final db = await _open();
    return db.insert('measurements', m.toMap());
  }

  Future<List<Measurement>> listAll({int limit = 300}) async {
    final db = await _open();
    final rows = await db.query(
      'measurements',
      orderBy: 'end_ms DESC',
      limit: limit,
    );
    return rows.map(Measurement.fromMap).toList();
  }

  Future<void> delete(int id) async {
    final db = await _open();
    await db.delete('measurements', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> clear() async {
    final db = await _open();
    await db.delete('measurements');
  }

  Future<void> close() async {
    await _db?.close();
    _db = null;
  }
}
