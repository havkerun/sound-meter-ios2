import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';

/// 偏好设置 + 校准偏移的持久化。
class SettingsStore extends ChangeNotifier {
  static const _kCalibOffset = 'calib_offset_db';
  static const _kWeighting = 'default_weighting';
  static const _kTimeWeighting = 'default_time_weighting';
  static const _kKeepScreenOn = 'keep_screen_on';
  static const _kCalibrated = 'has_calibrated';

  final SharedPreferences _prefs;

  SettingsStore._(this._prefs);

  static Future<SettingsStore> load() async {
    final prefs = await SharedPreferences.getInstance();
    return SettingsStore._(prefs);
  }

  /// 校准偏移：测量结果 = 原始计算值 + 该偏移
  double get calibrationOffsetDb => _prefs.getDouble(_kCalibOffset) ?? 0.0;

  /// 是否已经做过校准（用于首页提示条）
  bool get hasCalibrated => _prefs.getBool(_kCalibrated) ?? false;

  FrequencyWeighting get defaultWeighting => FrequencyWeighting.values
      .firstWhere(
        (e) => e.name == _prefs.getString(_kWeighting),
        orElse: () => FrequencyWeighting.a,
      );

  TimeWeighting get defaultTimeWeighting => TimeWeighting.values.firstWhere(
        (e) => e.name == _prefs.getString(_kTimeWeighting),
        orElse: () => TimeWeighting.fast,
      );

  bool get keepScreenOn => _prefs.getBool(_kKeepScreenOn) ?? true;

  Future<void> setCalibrationOffset(double value) async {
    await _prefs.setDouble(_kCalibOffset, value);
    await _prefs.setBool(_kCalibrated, true);
    notifyListeners();
  }

  Future<void> resetCalibration() async {
    await _prefs.setDouble(_kCalibOffset, 0);
    await _prefs.setBool(_kCalibrated, false);
    notifyListeners();
  }

  Future<void> setDefaultWeighting(FrequencyWeighting w) async {
    await _prefs.setString(_kWeighting, w.name);
    notifyListeners();
  }

  Future<void> setDefaultTimeWeighting(TimeWeighting t) async {
    await _prefs.setString(_kTimeWeighting, t.name);
    notifyListeners();
  }

  Future<void> setKeepScreenOn(bool v) async {
    await _prefs.setBool(_kKeepScreenOn, v);
    notifyListeners();
  }
}
