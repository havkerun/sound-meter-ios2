import 'package:flutter/material.dart';

import 'core/audio/mic_source.dart';
import 'data/measurement_dao.dart';
import 'data/settings_store.dart';
import 'state/meter_controller.dart';
import 'theme.dart';
import 'ui/history_page.dart';
import 'ui/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = await SettingsStore.load();
  final dao = MeasurementDao();
  runApp(SoundMeterApp(settings: settings, dao: dao));
}

class SoundMeterApp extends StatefulWidget {
  const SoundMeterApp({
    super.key,
    required this.settings,
    required this.dao,
  });

  final SettingsStore settings;
  final MeasurementDao dao;

  @override
  State<SoundMeterApp> createState() => _SoundMeterAppState();
}

class _SoundMeterAppState extends State<SoundMeterApp> {
  late final MeterController _controller;
  int _tab = 0;

  /// 每保存一条记录 +1，用来通知历史页重新查询
  int _historyToken = 0;

  @override
  void initState() {
    super.initState();
    _controller = MeterController(
      settings: widget.settings,
      mic: RecordMicSource(),
      dao: widget.dao,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '曾哥声压测量',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: Scaffold(
        body: IndexedStack(
          index: _tab,
          children: [
            HomePage(
              controller: _controller,
              settings: widget.settings,
              onHistoryChanged: () => setState(() => _historyToken++),
            ),
            HistoryPage(
              dao: widget.dao,
              reloadToken: _historyToken,
            ),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          height: 62,
          backgroundColor: AppColors.surface,
          indicatorColor: AppColors.primary.withAlpha(24),
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.graphic_eq_outlined),
              selectedIcon: Icon(Icons.graphic_eq),
              label: '测量',
            ),
            NavigationDestination(
              icon: Icon(Icons.history_outlined),
              selectedIcon: Icon(Icons.history),
              label: '记录',
            ),
          ],
        ),
      ),
    );
  }
}
