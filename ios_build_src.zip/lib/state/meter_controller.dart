import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../core/audio/mic_source.dart';
import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';
import '../data/measurement.dart';
import '../data/measurement_dao.dart';
import '../data/settings_store.dart';

/// 测量流程的总控：开关麦克风、喂数据给 DSP、把读数抛给界面、结束时落库。
///
/// 界面只认这个类，不直接碰音频与算法。
class MeterController extends ChangeNotifier {
  MeterController({
    required this.settings,
    required this.mic,
    required this.dao,
  }) {
    _meter = SoundLevelMeter(
      sampleRate: sampleRate,
      calibrationOffsetDb: settings.calibrationOffsetDb,
      weighting: settings.defaultWeighting,
      timeWeighting: settings.defaultTimeWeighting,
    );
    _reading = LevelReading.zero;
  }

  static const int sampleRate = 48000;

  final SettingsStore settings;
  final MicSource mic;
  final MeasurementDao dao;

  late SoundLevelMeter _meter;
  LevelReading _reading = LevelReading.zero;

  StreamSubscription<Int16List>? _sub;
  DateTime _lastNotify = DateTime.fromMillisecondsSinceEpoch(0);

  bool _measuring = false;
  bool _preview = false;
  DateTime? _startedAt;
  String? _error;

  bool get measuring => _measuring;

  /// true 表示当前是"只看读数不记录"的试采（校准页用）
  bool get preview => _preview;
  String? get error => _error;

  double get currentDb => _reading.db;
  double get maxDb => _reading.maxDb;
  double get minDb => _reading.minDb;
  double get leqDb => _reading.leqDb;
  Duration get elapsed =>
      Duration(milliseconds: (_reading.elapsedSeconds * 1000).round());

  /// 实时时间历程序列（每秒一个点）。只读，界面直接拿它画曲线。
  List<double> get series => _meter.series;

  FrequencyWeighting get weighting => _meter.weighting;
  TimeWeighting get timeWeighting => _meter.timeWeighting;

  /// 开始采集。[preview] 为 true 时不产生测量记录（校准用）。
  Future<void> start({bool preview = false}) async {
    if (_measuring) return;
    _error = null;

    try {
      final granted = await mic.hasPermission();
      if (!granted) {
        _error = '没有麦克风权限，无法测量。请到系统设置里允许本应用使用麦克风。';
        notifyListeners();
        return;
      }

      _meter.calibrationOffsetDb = settings.calibrationOffsetDb;
      _meter.reset();

      final stream = await mic.start(sampleRate: sampleRate);
      _sub = stream.listen(
        _onPcm,
        onError: (Object e) {
          _error = '麦克风采集出错：$e';
          notifyListeners();
        },
      );

      _measuring = true;
      _preview = preview;
      _startedAt = DateTime.now();
      _reading = LevelReading.zero;

      if (settings.keepScreenOn) {
        await WakelockPlus.enable();
      }
      notifyListeners();
    } catch (e) {
      _measuring = false;
      _error = '启动失败：$e';
      notifyListeners();
    }
  }

  void _onPcm(Int16List samples) {
    final reading = _meter.processChunk(samples);
    _reading = reading;

    // 音频块可能有 20~40ms 一块，这里限流到约 16fps，避免无意义的整页重绘
    final now = DateTime.now();
    if (now.difference(_lastNotify).inMilliseconds >= 60) {
      _lastNotify = now;
      notifyListeners();
    }
  }

  /// 停止采集。返回本次测量记录（preview 模式下返回 null）。
  Future<Measurement?> stop({bool save = true}) async {
    if (!_measuring) return null;

    await _sub?.cancel();
    _sub = null;
    await mic.stop();
    await WakelockPlus.disable();

    _measuring = false;
    final startedAt = _startedAt ?? DateTime.now();
    final endedAt = DateTime.now();

    final stats = _meter.computeStats();
    final measurement = Measurement(
      startTime: startedAt,
      endTime: endedAt,
      leqDb: _reading.leqDb,
      maxDb: _reading.maxDb,
      minDb: _reading.minDb,
      l10Db: stats.l10,
      l50Db: stats.l50,
      l90Db: stats.l90,
      series: List<double>.of(_meter.series),
      weighting: _meter.weighting,
      timeWeighting: _meter.timeWeighting,
      calibrationOffsetDb: _meter.calibrationOffsetDb,
    );

    final wasPreview = _preview;
    _preview = false;
    _startedAt = null;
    notifyListeners();

    if (wasPreview || !save) return null;

    // 太短的测量（少于 2 秒）没有统计意义，不落库
    if (endedAt.difference(startedAt).inSeconds < 2) return null;

    final id = await dao.insert(measurement);
    return measurement.copyWith(id: id);
  }

  void setWeighting(FrequencyWeighting w) {
    _meter.setWeighting(w);
    notifyListeners();
  }

  void setTimeWeighting(TimeWeighting t) {
    _meter.setTimeWeighting(t);
    notifyListeners();
  }

  /// 校准后立即生效，不必重启测量
  void applyCalibrationOffset(double offset) {
    _meter.calibrationOffsetDb = offset;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    mic.dispose();
    WakelockPlus.disable();
    super.dispose();
  }
}
