import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';
import '../data/settings_store.dart';
import '../state/meter_controller.dart';
import '../theme.dart';
import 'widgets/app_card.dart';

/// 校准页。
///
/// 手机麦克风没有出厂声压标定，读数会有固定的系统偏差。用户拿一台已校准的
/// 声级计（或标准声源）在同一位置对比，把"参考值"填进来，App 算出偏差并保存，
/// 之后所有测量都会自动加上这个偏移。
class CalibrationPage extends StatefulWidget {
  const CalibrationPage({
    super.key,
    required this.controller,
    required this.settings,
  });

  final MeterController controller;
  final SettingsStore settings;

  @override
  State<CalibrationPage> createState() => _CalibrationPageState();
}

class _CalibrationPageState extends State<CalibrationPage> {
  final TextEditingController _refInput = TextEditingController();

  @override
  void dispose() {
    _refInput.dispose();
    // 退出页面时收掉试采，避免麦克风一直开着
    if (widget.controller.preview) {
      Future.microtask(() => widget.controller.stop(save: false));
    }
    super.dispose();
  }

  double? get _referenceDb {
    final v = double.tryParse(_refInput.text.trim());
    if (v == null || v < 20 || v > 140) return null;
    return v;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('麦克风校准')),
      body: AnimatedBuilder(
        animation: widget.controller,
        builder: (context, _) {
          final c = widget.controller;
          final reading = c.currentDb;
          final ref = _referenceDb;
          final offset = (ref != null && c.measuring) ? ref - reading : null;

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              AppCard(
                color: const Color(0xFFFAEEDA),
                child: const Text(
                  '把手机和一台已校准的声级计放在同一位置、同一个朝向，'
                  '观察两边读数是否一致。把对方仪器的读数填到下面，App 会自动算出偏差。',
                  style: TextStyle(
                    fontSize: 13,
                    height: 1.6,
                    color: Color(0xFF854F0B),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              AppCard(
                child: Column(
                  children: [
                    const Text(
                      '当前读数',
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      c.measuring ? reading.toStringAsFixed(1) : '--',
                      style: const TextStyle(
                        fontSize: 54,
                        fontWeight: FontWeight.w300,
                        height: 1.0,
                        letterSpacing: -1.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'dB(${c.weighting.label}) · ${c.timeWeighting.label}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton(
                        onPressed: () => _toggleAcquire(c),
                        child: Text(c.preview ? '停止采集' : '开始采集'),
                      ),
                    ),
                    if (c.measuring && !c.preview) ...[
                      const SizedBox(height: 8),
                      const Text(
                        '首页正在测量中，请先回到首页停止测量再来校准',
                        style: TextStyle(
                          fontSize: 12,
                          color: Color(0xFFA32D2D),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),
              AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '参考仪器读数',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _refInput,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                      ],
                      decoration: const InputDecoration(
                        hintText: '例如 65.3',
                        suffixText: 'dB',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.pageBg,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            '计算出的偏移',
                            style: TextStyle(
                              fontSize: 13,
                              color: AppColors.textSecondary,
                            ),
                          ),
                          Text(
                            offset == null
                                ? '--'
                                : '${offset >= 0 ? '+' : ''}'
                                    '${offset.toStringAsFixed(1)} dB',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: offset == null ? null : () => _save(offset),
                        child: const Text('保存校准'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: TextButton(
                        onPressed: _reset,
                        child: const Text('重置为默认（0 dB）'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                '说明：本次校准偏移只对当前这台手机的麦克风有效。'
                '换手机、换手机壳、外接麦克风后都需要重新校准。',
                style: TextStyle(
                  fontSize: 12,
                  height: 1.6,
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _toggleAcquire(MeterController c) async {
    if (c.measuring && c.preview) {
      await c.stop(save: false);
    } else if (!c.measuring) {
      await c.start(preview: true);
      if (c.error != null && mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(c.error!)));
      }
    }
  }

  Future<void> _save(double offset) async {
    await widget.settings.setCalibrationOffset(offset);
    widget.controller.applyCalibrationOffset(offset);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已保存校准偏移 ${offset.toStringAsFixed(1)} dB')),
    );
    Navigator.of(context).pop();
  }

  Future<void> _reset() async {
    await widget.settings.resetCalibration();
    widget.controller.applyCalibrationOffset(0);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('已重置为默认')));
  }
}
