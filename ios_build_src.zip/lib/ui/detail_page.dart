import 'package:flutter/material.dart';

import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';
import '../core/level_zone.dart';
import '../data/measurement.dart';
import '../theme.dart';
import 'report_page.dart';
import 'widgets/app_card.dart';
import 'widgets/level_chart.dart';

class DetailPage extends StatelessWidget {
  const DetailPage({super.key, required this.measurement});

  final Measurement measurement;

  @override
  Widget build(BuildContext context) {
    final m = measurement;
    final zone = LevelZone.of(m.leqDb);

    return Scaffold(
      appBar: AppBar(
        title: const Text('测量详情'),
        actions: [
          IconButton(
            tooltip: '生成报告',
            icon: const Icon(Icons.description_outlined),
            onPressed: () => _openReport(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      '${m.startTime.year}-${_two(m.startTime.month)}-'
                      '${_two(m.startTime.day)} '
                      '${_two(m.startTime.hour)}:${_two(m.startTime.minute)}',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '时长 ${m.durationText}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(
                      m.leqDb.toStringAsFixed(1),
                      style: TextStyle(
                        fontSize: 56,
                        height: 1.0,
                        fontWeight: FontWeight.w300,
                        color: zone.color,
                        letterSpacing: -1.5,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'dB(${m.weighting.label})',
                      style: const TextStyle(
                        fontSize: 14,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '等效连续声级 Leq · ${zone.label} · ${zone.tip}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // 时间历程曲线
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '声级时间历程',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  m.series.isEmpty
                      ? '本次记录没有曲线数据'
                      : '每秒一个测点，共 ${m.series.length} 个 · 虚线为整段 Leq',
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 10),
                LevelChart(
                  values: m.series,
                  height: 150,
                  color: zone.color,
                  referenceDb: m.leqDb,
                  referenceLabel: 'Leq',
                  emptyHint: '',
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          // 统计指标
          AppCard(
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(child: _Stat(label: '最大值', value: m.maxDb.toStringAsFixed(1))),
                    Expanded(child: _Stat(label: '最小值', value: m.minDb.toStringAsFixed(1))),
                    Expanded(
                      child: _Stat(
                        label: 'L10',
                        value: _fmt(m.l10Db),
                        hint: '10% 时间超过',
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: _Stat(
                        label: 'L50',
                        value: _fmt(m.l50Db),
                        hint: '中位数',
                      ),
                    ),
                    Expanded(
                      child: _Stat(
                        label: 'L90',
                        value: _fmt(m.l90Db),
                        hint: '背景噪声',
                      ),
                    ),
                    Expanded(
                      child: _Stat(
                        label: '测点',
                        value: '${m.series.length}',
                        hint: '个 1 秒',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),

          AppCard(
            child: Column(
              children: [
                _Row(label: '频率计权', value: m.weighting.fullName),
                const Divider(height: 22),
                _Row(label: '时间计权', value: m.timeWeighting.label),
                const Divider(height: 22),
                _Row(
                  label: '校准偏移',
                  value: '${m.calibrationOffsetDb >= 0 ? '+' : ''}'
                      '${m.calibrationOffsetDb.toStringAsFixed(1)} dB'
                      '${m.calibrationOffsetDb == 0 ? '（未校准）' : ''}',
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          FilledButton.icon(
            onPressed: () => _openReport(context),
            icon: const Icon(Icons.description_outlined, size: 18),
            label: const Text('生成测量报告'),
          ),
          const SizedBox(height: 14),
          const Text(
            'Leq 是把整段时间的能量平均后换算成 dB，比"平均读数"更接近人对噪声的整体感受；'
            'L10 反映吵闹时段，L90 反映背景噪声，两者之差越大说明噪声起伏越明显。',
            style: TextStyle(
              fontSize: 12,
              height: 1.6,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  void _openReport(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ReportPage(measurement: measurement)),
    );
  }

  static String _fmt(double? v) => v == null ? '—' : v.toStringAsFixed(1);

  static String _two(int v) => v.toString().padLeft(2, '0');
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value, this.hint});

  final String label;
  final String value;
  final String? hint;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
        ),
        if (hint != null) ...[
          const SizedBox(height: 2),
          Text(
            hint!,
            style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
          ),
        ],
      ],
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        ),
        Text(
          value,
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
        ),
      ],
    );
  }
}
