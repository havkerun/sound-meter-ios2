import 'package:flutter/material.dart';

import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';
import '../core/level_zone.dart';
import '../data/measurement.dart';
import '../data/settings_store.dart';
import '../state/meter_controller.dart';
import '../theme.dart';
import 'calibration_page.dart';
import 'detail_page.dart';
import 'settings_page.dart';
import 'widgets/app_card.dart';
import 'widgets/level_bar.dart';
import 'widgets/level_chart.dart';

class HomePage extends StatelessWidget {
  const HomePage({
    super.key,
    required this.controller,
    required this.settings,
    required this.onHistoryChanged,
  });

  final MeterController controller;
  final SettingsStore settings;

  /// 保存新记录后通知外层刷新历史列表
  final VoidCallback onHistoryChanged;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([controller, settings]),
      builder: (context, _) {
        final zone = LevelZone.of(controller.currentDb);
        final measuring = controller.measuring;

        return Scaffold(
          appBar: AppBar(
            title: const Text('曾哥声压测量'),
            actions: [
              IconButton(
                tooltip: '校准',
                icon: const Icon(Icons.tune),
                onPressed: () => _openCalibration(context),
              ),
              IconButton(
                tooltip: '设置',
                icon: const Icon(Icons.settings_outlined),
                onPressed: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => SettingsPage(
                        controller: controller,
                        settings: settings,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              children: [
                if (!settings.hasCalibrated) _calibrationBanner(context),
                if (!settings.hasCalibrated) const SizedBox(height: 12),
                _readout(zone, measuring),
                const SizedBox(height: 18),
                _weightingSelector(measuring),
                const SizedBox(height: 18),
                LevelBar(db: controller.currentDb),
                const SizedBox(height: 16),
                if (measuring) ...[
                  _liveChart(zone),
                  const SizedBox(height: 14),
                ],
                _tipCard(zone),
                const SizedBox(height: 14),
                _statsRow(measuring),
                const SizedBox(height: 20),
                _mainButton(context, measuring),
                if (measuring) ...[
                  const SizedBox(height: 10),
                  Center(
                    child: Text(
                      '已测量 ${_fmtDuration(controller.elapsed)}'
                      '${controller.preview ? '（校准试采，不保存）' : ''}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _calibrationBanner(BuildContext context) {
    return InkWell(
      onTap: () => _openCalibration(context),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: const Color(0xFFFAEEDA),
          borderRadius: BorderRadius.circular(10),
        ),
        child: const Row(
          children: [
            Icon(Icons.info_outline, size: 16, color: Color(0xFF854F0B)),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                '还没校准，数值可能与专业仪器有偏差 · 点这里去校准',
                style: TextStyle(fontSize: 12, color: Color(0xFF854F0B)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _readout(LevelZone zone, bool measuring) {
    final db = controller.currentDb;
    final showValue = measuring || db > 0;
    final text = showValue ? db.toStringAsFixed(1) : '--';
    final unit = 'dB(${controller.weighting.label})';

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Text(
              text,
              style: TextStyle(
                fontSize: 76,
                height: 1.0,
                fontWeight: FontWeight.w300,
                letterSpacing: -2,
                color: showValue ? zone.color : AppColors.textSecondary,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              unit,
              style: const TextStyle(
                fontSize: 15,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          controller.timeWeighting.label,
          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
      ],
    );
  }

  Widget _weightingSelector(bool measuring) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (final w in FrequencyWeighting.values)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: _Chip(
              label: w.fullName,
              selected: controller.weighting == w,
              onTap: () => controller.setWeighting(w),
            ),
          ),
      ],
    );
  }

  /// 测量中的实时曲线（最近 60 秒）
  Widget _liveChart(LevelZone zone) {
    final all = controller.series;
    final values = all.length <= 60 ? all : all.sublist(all.length - 60);
    return AppCard(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  '最近 60 秒',
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                ),
                Text(
                  '${all.length} 个测点 · 虚线为 Leq',
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          LevelChart(
            values: values,
            height: 88,
            color: zone.color,
            referenceDb: controller.leqDb,
            showAxis: false,
            emptyHint: '满 1 秒后开始绘制',
          ),
        ],
      ),
    );
  }

  Widget _tipCard(LevelZone zone) {
    return AppCard(
      color: zone.color.withAlpha(18),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Container(
            width: 6,
            height: 34,
            decoration: BoxDecoration(
              color: zone.color,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${zone.label} · ${zone.tip}',
                  style: TextStyle(
                    fontSize: 13,
                    color: zone.color,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  zone.riskHint,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _statsRow(bool measuring) {
    return Row(
      children: [
        Expanded(
          child: _StatTile(
            label: '最大',
            value: measuring ? controller.maxDb.toStringAsFixed(1) : '--',
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _StatTile(
            label: '最小',
            value: measuring ? controller.minDb.toStringAsFixed(1) : '--',
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _StatTile(
            label: '等效 Leq',
            value: measuring ? controller.leqDb.toStringAsFixed(1) : '--',
          ),
        ),
      ],
    );
  }

  Widget _mainButton(BuildContext context, bool measuring) {
    if (!measuring) {
      return FilledButton(
        onPressed: () async {
          await controller.start();
          if (controller.error != null && context.mounted) {
            _snack(context, controller.error!);
          }
        },
        child: const Text('开始测量'),
      );
    }
    return FilledButton(
      style: FilledButton.styleFrom(backgroundColor: const Color(0xFFA32D2D)),
      onPressed: () async {
        final m = await controller.stop();
        if (!context.mounted) return;
        if (m == null) {
          _snack(context, '本次测量时长不足 2 秒，未保存');
          return;
        }
        onHistoryChanged();
        _showSaved(context, m);
      },
      child: const Text('停止并保存'),
    );
  }

  void _showSaved(BuildContext context, Measurement m) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('已保存：Leq ${m.leqDb.toStringAsFixed(1)} dB'),
        action: SnackBarAction(
          label: '查看',
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => DetailPage(measurement: m)),
            );
          },
        ),
      ),
    );
  }

  void _snack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _openCalibration(BuildContext context) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => CalibrationPage(controller: controller, settings: settings),
      ),
    );
  }

  static String _fmtDuration(Duration d) {
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class _Chip extends StatelessWidget {
  const _Chip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.divider,
            width: 0.8,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
            color: selected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

class _StatTile extends StatelessWidget {
  const _StatTile({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.divider, width: 0.5),
      ),
      child: Column(
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: AppColors.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}
