import 'package:flutter/material.dart';

import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';
import '../core/level_zone.dart';
import '../core/report_exporter.dart';
import '../data/measurement.dart';
import '../theme.dart';
import 'widgets/level_chart.dart';

/// 测量报告页：展示一张可导出的报告卡片，底部一键生成图片并分享。
class ReportPage extends StatefulWidget {
  const ReportPage({super.key, required this.measurement});

  final Measurement measurement;

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage> {
  final GlobalKey _reportKey = GlobalKey();
  bool _exporting = false;

  @override
  Widget build(BuildContext context) {
    final m = widget.measurement;
    final zone = LevelZone.of(m.leqDb);

    return Scaffold(
      appBar: AppBar(title: const Text('测量报告')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          RepaintBoundary(
            key: _reportKey,
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        '环境噪声测量报告',
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: zone.color.withAlpha(28),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          zone.label,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: zone.color,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${_fmtDate(m.startTime)} — ${_fmtTime(m.endTime)}',
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Divider(height: 1, color: AppColors.divider),
                  const SizedBox(height: 16),

                  // 主指标
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text(
                        m.leqDb.toStringAsFixed(1),
                        style: TextStyle(
                          fontSize: 46,
                          height: 1.0,
                          fontWeight: FontWeight.w300,
                          letterSpacing: -1.5,
                          color: zone.color,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        'dB(${m.weighting.label})',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    '等效连续声级 Leq',
                    style: TextStyle(fontSize: 10, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 18),

                  // 曲线
                  SizedBox(
                    width: double.infinity,
                    child: LevelChart(
                      values: m.series,
                      height: 130,
                      color: zone.color,
                      referenceDb: m.leqDb,
                      emptyHint: '本次测量没有曲线数据',
                      showAxis: true,
                    ),
                  ),
                  const SizedBox(height: 18),

                  // 指标网格
                  Wrap(
                    spacing: 0,
                    runSpacing: 0,
                    children: [
                      _cell('最大值', m.maxDb.toStringAsFixed(1)),
                      _cell('最小值', m.minDb.toStringAsFixed(1)),
                      _cell('L10', _fmt(m.l10Db)),
                      _cell('L50', _fmt(m.l50Db)),
                      _cell('L90', _fmt(m.l90Db)),
                      _cell('时长', m.durationText),
                    ].map((w) => SizedBox(width: 155, child: w)).toList(),
                  ),

                  const SizedBox(height: 14),
                  const Divider(height: 1, color: AppColors.divider),
                  const SizedBox(height: 12),

                  // 参数
                  _param('频率计权', m.weighting.fullName),
                  _param('时间计权', m.timeWeighting.label),
                  _param(
                    '校准偏移',
                    '${m.calibrationOffsetDb >= 0 ? '+' : ''}'
                        '${m.calibrationOffsetDb.toStringAsFixed(1)} dB'
                        '${m.calibrationOffsetDb == 0 ? '（未校准）' : ''}',
                  ),
                  _param(
                    '采样 / 测点',
                    '48 kHz · ${m.series.length} 个 1 秒测点',
                  ),
                  _param(
                    '合规参考',
                    '《声环境质量标准》GB 3096 居民区昼间 55 dB(A)、夜间 45 dB(A)',
                  ),

                  const SizedBox(height: 14),
                  const Text(
                    '说明：本报告由手机应用测量生成。手机麦克风非计量器具，'
                    '读数受机型、保护壳、持握方式影响，仅用于参考与沟通说明，'
                    '不作为法定检测或执法依据。',
                    style: TextStyle(
                      fontSize: 9,
                      height: 1.6,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        '曾哥声压测量 App',
                        style: TextStyle(
                          fontSize: 9,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      Text(
                        '导出时间 ${_fmtDate(DateTime.now())}',
                        style: const TextStyle(
                          fontSize: 9,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _exporting ? null : _share,
            icon: const Icon(Icons.ios_share, size: 18),
            label: Text(_exporting ? '正在生成…' : '生成图片并分享'),
          ),
          const SizedBox(height: 10),
          const Text(
            '生成的是一张图片，可直接发微信给物业、房东或厂家。',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }

  Widget _cell(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _param(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 72,
            child: Text(
              label,
              style: const TextStyle(
                fontSize: 10,
                color: AppColors.textSecondary,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontSize: 10, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _share() async {
    setState(() => _exporting = true);
    try {
      // 等一帧，确保报告卡片已经完成布局
      await Future<void>.delayed(const Duration(milliseconds: 80));
      await ReportExporter.share(
        _reportKey,
        text: '环境噪声测量：Leq ${widget.measurement.leqDb.toStringAsFixed(1)} '
            'dB(${widget.measurement.weighting.label})',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('生成报告失败：$e')));
      }
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  static String _fmt(double? v) => v == null ? '—' : v.toStringAsFixed(1);

  static String _fmtDate(DateTime t) =>
      '${t.year}-${_two(t.month)}-${_two(t.day)}';

  static String _fmtTime(DateTime t) =>
      '${_two(t.hour)}:${_two(t.minute)}';

  static String _two(int v) => v.toString().padLeft(2, '0');
}
