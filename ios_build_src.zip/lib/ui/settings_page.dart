import 'package:flutter/material.dart';

import '../core/dsp/sound_level_meter.dart';
import '../core/dsp/weighting_filter.dart';
import '../data/settings_store.dart';
import '../state/meter_controller.dart';
import '../theme.dart';
import 'calibration_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({
    super.key,
    required this.controller,
    required this.settings,
  });

  final MeterController controller;
  final SettingsStore settings;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('设置')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              _sectionTitle('计权方式'),
              _card(
                Column(
                  children: [
                    for (final w in FrequencyWeighting.values)
                      RadioListTile<FrequencyWeighting>(
                        value: w,
                        groupValue: settings.defaultWeighting,
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          w.fullName,
                          style: const TextStyle(fontSize: 14),
                        ),
                        subtitle: Text(
                          _weightingHint(w),
                          style: const TextStyle(fontSize: 12),
                        ),
                        onChanged: (v) async {
                          if (v == null) return;
                          await settings.setDefaultWeighting(v);
                          controller.setWeighting(v);
                        },
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              _sectionTitle('时间计权'),
              _card(
                Column(
                  children: [
                    for (final t in TimeWeighting.values)
                      RadioListTile<TimeWeighting>(
                        value: t,
                        groupValue: settings.defaultTimeWeighting,
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        title: Text(
                          t.label,
                          style: const TextStyle(fontSize: 14),
                        ),
                        subtitle: Text(
                          t == TimeWeighting.fast
                              ? '反应快，读数跳动明显，适合看瞬时变化'
                              : '反应平缓，读数稳定，适合长时间观察',
                          style: const TextStyle(fontSize: 12),
                        ),
                        onChanged: (v) async {
                          if (v == null) return;
                          await settings.setDefaultTimeWeighting(v);
                          controller.setTimeWeighting(v);
                        },
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              _sectionTitle('显示'),
              _card(
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: settings.keepScreenOn,
                  onChanged: (v) => settings.setKeepScreenOn(v),
                  title: const Text('测量时保持屏幕常亮',
                      style: TextStyle(fontSize: 14)),
                  subtitle: const Text('避免测量中途息屏中断',
                      style: TextStyle(fontSize: 12)),
                ),
              ),
              const SizedBox(height: 18),
              _sectionTitle('校准'),
              _card(
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('麦克风校准', style: TextStyle(fontSize: 14)),
                  subtitle: Text(
                    settings.hasCalibrated
                        ? '当前偏移 ${settings.calibrationOffsetDb.toStringAsFixed(1)} dB'
                        : '尚未校准（偏移 0 dB）',
                    style: const TextStyle(fontSize: 12),
                  ),
                  trailing: const Icon(Icons.chevron_right, size: 20),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => CalibrationPage(
                        controller: controller,
                        settings: settings,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              _sectionTitle('数据'),
              _card(
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('清空所有测量记录',
                      style: TextStyle(fontSize: 14, color: Color(0xFFA32D2D))),
                  subtitle: const Text('删除后无法恢复',
                      style: TextStyle(fontSize: 12)),
                  onTap: () => _confirmClear(context),
                ),
              ),
              const SizedBox(height: 18),
              _sectionTitle('关于'),
              _card(
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 4),
                  child: Text(
                    '本应用为参考性测量工具，校准后可用于日常噪声判断与沟通说明，'
                    '不可作为法定计量、执法或法律取证依据。\n\n'
                    '手机麦克风的有效量程约为 30–120 dB，超出范围会削波失真；'
                    '不同机型麦克风的频响曲线不同，读数存在个体差异。',
                    style: TextStyle(
                      fontSize: 12,
                      height: 1.7,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Center(
                child: Text(
                  '曾哥声压测量 v1.0.1',
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 8),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
          ),
        ),
      );

  Widget _card(Widget child) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.divider, width: 0.5),
        ),
        child: child,
      );

  static String _weightingHint(FrequencyWeighting w) => switch (w) {
        FrequencyWeighting.a => '最常用，模拟人耳对低频不敏感（噪声评价默认）',
        FrequencyWeighting.c => '低频保留更多，适合看机械、音响、低频轰鸣',
        FrequencyWeighting.z => '完全平直，不加权，看原始能量',
      };

  Future<void> _confirmClear(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('清空所有记录？'),
        content: const Text('这会删除全部测量记录，且无法恢复。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('取消'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('清空', style: TextStyle(color: Color(0xFFA32D2D))),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await controller.dao.clear();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('已清空所有记录')));
  }
}
