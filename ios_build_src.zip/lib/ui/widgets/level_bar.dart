import 'package:flutter/material.dart';

import '../../core/level_zone.dart';
import '../../theme.dart';

/// 动态分贝柱状条：一格一格亮起来，比指针表盘更容易"一眼看懂"。
class LevelBar extends StatelessWidget {
  const LevelBar({
    super.key,
    required this.db,
    this.minDb = 20,
    this.maxDb = 120,
    this.height = 14,
    this.showScale = true,
  });

  final double db;
  final double minDb;
  final double maxDb;
  final double height;
  final bool showScale;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: height,
          child: CustomPaint(
            painter: _LevelBarPainter(
              db: db,
              minDb: minDb,
              maxDb: maxDb,
            ),
          ),
        ),
        if (showScale) ...[
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (final v in [30, 60, 90, 120])
                Text(
                  '$v',
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
            ],
          ),
        ],
      ],
    );
  }
}

class _LevelBarPainter extends CustomPainter {
  _LevelBarPainter({
    required this.db,
    required this.minDb,
    required this.maxDb,
  });

  final double db;
  final double minDb;
  final double maxDb;

  static const int _segments = 56;
  static const double _gap = 2.0;

  @override
  void paint(Canvas canvas, Size size) {
    final segWidth = (size.width - _gap * (_segments - 1)) / _segments;
    final paint = Paint()..style = PaintingStyle.fill;
    final span = maxDb - minDb;

    for (var i = 0; i < _segments; i++) {
      final left = i * (segWidth + _gap);
      // 该格代表的分贝范围
      final segDb = minDb + span * (i + 0.5) / _segments;
      final lit = db >= segDb;
      paint.color = lit ? LevelZone.of(segDb).color : AppColors.trackBg;
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(left, 0, segWidth, size.height),
        const Radius.circular(2),
      );
      canvas.drawRRect(rect, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _LevelBarPainter old) =>
      old.db != db || old.minDb != minDb || old.maxDb != maxDb;
}
