import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../theme.dart';

/// 时间历程曲线（dB 随时间变化）。
///
/// 自己画而不是引第三方图表库的原因：只要一条折线 + 几条网格线，
/// 引库会给安装包平白加几百 KB，样式还不好控。
class LevelChart extends StatelessWidget {
  const LevelChart({
    super.key,
    required this.values,
    this.height = 150,
    this.color = AppColors.primary,
    this.referenceDb,
    this.referenceLabel,
    this.emptyHint = '暂无曲线数据',
    this.showAxis = true,
  });

  /// 每秒一个的 dB 值
  final List<double> values;
  final double height;
  final Color color;

  /// 参考线（一般是 Leq），画成一条虚线
  final double? referenceDb;
  final String? referenceLabel;

  final String emptyHint;
  final bool showAxis;

  @override
  Widget build(BuildContext context) {
    if (values.isEmpty) {
      return SizedBox(
        height: height,
        child: Center(
          child: Text(
            emptyHint,
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.textSecondary,
            ),
          ),
        ),
      );
    }
    return SizedBox(
      height: height,
      child: CustomPaint(
        painter: _ChartPainter(
          values: values,
          color: color,
          referenceDb: referenceDb,
          referenceLabel: referenceLabel,
          showAxis: showAxis,
        ),
      ),
    );
  }
}

class _ChartPainter extends CustomPainter {
  _ChartPainter({
    required this.values,
    required this.color,
    required this.referenceDb,
    required this.referenceLabel,
    required this.showAxis,
  });

  final List<double> values;
  final Color color;
  final double? referenceDb;
  final String? referenceLabel;
  final bool showAxis;

  /// 点太多时按桶降采样，避免一次画上万个点掉帧
  static const int _maxPoints = 400;

  @override
  void paint(Canvas canvas, Size size) {
    final leftPad = showAxis ? 30.0 : 4.0;
    final bottomPad = showAxis ? 16.0 : 4.0;
    final plot = Rect.fromLTRB(leftPad, 6, size.width - 4, size.height - bottomPad);
    if (plot.width <= 0 || plot.height <= 0) return;

    final series = _downsample(values);

    // 纵轴范围：按数据自适应，取整到 10dB，最小跨度 20dB
    var lo = series.reduce(math.min);
    var hi = series.reduce(math.max);
    lo = (lo / 10).floor() * 10.0;
    hi = (hi / 10).ceil() * 10.0;
    if (hi - lo < 20) {
      final mid = (hi + lo) / 2;
      lo = mid - 10;
      hi = mid + 10;
    }

    // 网格线 + 纵轴刻度
    final gridPaint = Paint()
      ..color = AppColors.divider
      ..strokeWidth = 0.6;
    const lines = 4;
    for (var i = 0; i <= lines; i++) {
      final y = plot.top + plot.height * i / lines;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gridPaint);
      if (showAxis) {
        final db = hi - (hi - lo) * i / lines;
        _drawText(
          canvas,
          '${db.round()}',
          Offset(0, y - 6),
          const TextStyle(fontSize: 9, color: AppColors.textSecondary),
          width: leftPad - 4,
          align: TextAlign.right,
        );
      }
    }

    // 曲线
    final path = Path();
    for (var i = 0; i < series.length; i++) {
      final x = series.length == 1
          ? plot.left
          : plot.left + plot.width * i / (series.length - 1);
      final y = plot.top + (hi - series[i]) / (hi - lo) * plot.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    // 面积填充（纯色淡填充，不用渐变）
    final fill = Path.from(path)
      ..lineTo(plot.right, plot.bottom)
      ..lineTo(plot.left, plot.bottom)
      ..close();
    canvas.drawPath(fill, Paint()..color = color.withAlpha(20));

    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..strokeJoin = StrokeJoin.round,
    );

    // 参考线（Leq）
    final ref = referenceDb;
    if (ref != null && ref > lo && ref < hi) {
      final y = plot.top + (hi - ref) / (hi - lo) * plot.height;
      final dash = Paint()
        ..color = color.withAlpha(120)
        ..strokeWidth = 1;
      var x = plot.left;
      while (x < plot.right) {
        canvas.drawLine(Offset(x, y), Offset(math.min(x + 4, plot.right), y), dash);
        x += 8;
      }
      if (showAxis && referenceLabel != null) {
        _drawText(
          canvas,
          referenceLabel!,
          Offset(plot.right - 70, y - 13),
          TextStyle(fontSize: 9, color: color),
          width: 70,
          align: TextAlign.right,
        );
      }
    }
  }

  /// 桶平均降采样
  List<double> _downsample(List<double> src) {
    if (src.length <= _maxPoints) return src;
    final out = <double>[];
    final bucket = src.length / _maxPoints;
    for (var i = 0; i < _maxPoints; i++) {
      final start = (i * bucket).floor();
      final end = math.min(((i + 1) * bucket).ceil(), src.length);
      var sum = 0.0;
      var n = 0;
      for (var j = start; j < end; j++) {
        sum += src[j];
        n++;
      }
      out.add(n == 0 ? src[start] : sum / n);
    }
    return out;
  }

  void _drawText(
    Canvas canvas,
    String text,
    Offset offset,
    TextStyle style, {
    required double width,
    TextAlign align = TextAlign.left,
  }) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
      textAlign: align,
    )..layout(minWidth: width, maxWidth: width);
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _ChartPainter old) =>
      old.values.length != values.length ||
      old.values != values ||
      old.referenceDb != referenceDb ||
      old.color != color;
}
